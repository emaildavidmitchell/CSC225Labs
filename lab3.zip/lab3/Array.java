public class Array
{
	int arr[];
	int arr_count;

	public Array()
	{
		this.arr = new int[1];
		this.arr_count = 0;
	}
	
	public void grow()
	{
		int tmp[] = new int[this.arr.length+500];
		for (int i = 0; i < this.arr.length; i++)
		{
			tmp[i] = this.arr[i];
		}
		this.arr = tmp;
	}

	public void insert(int data)
	{
		if (this.arr_count > this.arr.length-1)
		{
			grow();
		}
		this.arr[this.arr_count] = data;
		this.arr_count++;
	}
}