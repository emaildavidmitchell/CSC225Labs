import java.util.*;

public class Lab3
{
	long startTime;
	long endTime;

	public Lab3()
	{

	}

	public static void main(String args[])
	{
		Lab3 l3 = new Lab3();
		l3.insertion(100000,100);
	}

	public void insertion(int num, int step)
	{
		CreateDataset cd = new CreateDataset();		

		double xy[][] = new double[num/step][2];
		LinkedList ll;
		for (int i = 0; i < xy.length; i++)
		{
			ll = new LinkedList();
			startClock();
			for (int j = 0; j < i*step; j++)
			{
				ll.insert(j);
			}
			stopClock();
			xy[i][0] = i*step;
			xy[i][1] = getDuration();
		}

		cd.addSeries(xy,"Linked List Insertion");


		Array arr;
		for (int i = 0; i < xy.length; i++)
		{
			arr = new Array();
			startClock();
			for (int j = 0; j < i*step; j++)
			{
				arr.insert(j);
			}
			stopClock();
			xy[i][0] = i*step;
			xy[i][1] = getDuration();
		}

		cd.addSeries(xy,"Array Insertion");


		GraphPlot gp = new GraphPlot("Array vs Linked List Insertion","Input size","Time in ms",cd.getDataset());

	}	



	public void startClock()
	{
		this.startTime = System.nanoTime();
	}

	public void stopClock()
	{
		this.endTime = System.nanoTime();
	}

	public double getDuration()
	{
		return (double)(this.endTime-this.startTime)/1000000;
	}

	

}