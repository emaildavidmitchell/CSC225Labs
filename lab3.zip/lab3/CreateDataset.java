import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public class CreateDataset
{
  XYSeriesCollection dataset;

  public CreateDataset()
  {
    this.dataset = new XYSeriesCollection();
  }

  public void resetDataset()
  {
    this.dataset = new XYSeriesCollection();
  }

  public void addSeries(double xy[][], String title)
  {
    XYSeries series = new XYSeries(title);

    for (int i = 0; i < xy.length; i++)
    {
      series.add(xy[i][0],xy[i][1]);
    }
    this.dataset.addSeries(series);
  }

  public XYDataset getDataset()
  {
    return this.dataset;
  }
}