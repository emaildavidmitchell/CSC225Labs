public class LinkedList
{
	ListNode start;
	ListNode rear;
	int n;

	public LinkedList()
	{
		n = 0;
		start = null;
		rear = null;
	}

	public void insert(int data)
	{
		ListNode tmp = new ListNode(data,null);

		if (this.start == null)
		{
			this.start = tmp;
		}
		else
		{
			this.rear.next = tmp;
		}
		this.rear = tmp;
	}

	public void printList()
	{
		ListNode current;
		int count=0;
		current= start;
		while (current != null)
		{
			count++;
			System.out.println("Item " + count + " in the list is " + current.data);
			current= current.next;
		}
	}
}

class ListNode
{
	int data;
	ListNode next;

	public ListNode(int d, ListNode n)
	{
		this.data = d;
		this.next = n;
	}

}