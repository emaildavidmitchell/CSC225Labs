
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public class GraphPlot extends JFrame
{
  
  public GraphPlot(String title, String xaxis, String yaxis, XYDataset dataset)
  {
    super(title);

    JFreeChart chart = ChartFactory.createScatterPlot(
      title, xaxis, yaxis, dataset);

    ChartPanel panel = new ChartPanel(chart);
    setContentPane(panel);
    SwingUtilities.invokeLater(() -> {
      this.setSize(800, 400);
      this.setLocationRelativeTo(null);
      this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
      this.setVisible(true);
    });


  }

}